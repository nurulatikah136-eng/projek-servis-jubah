
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD-eVswb9ZtRl3nMuHXBTyfKMDsiAWiZKg",
  authDomain: "projek-servis-jubah.firebaseapp.com",
  projectId: "projek-servis-jubah",
  storageBucket: "projek-servis-jubah.firebasestorage.app",
  messagingSenderId: "451948492185",
  appId: "1:451948492185:web:4eec944a220444a3474f08"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
